This folder contains the earlier skeleton files. After dockerizing the project,
copy the skeleton content into the Laravel project (or create a fresh Laravel app
and then copy these files over).
