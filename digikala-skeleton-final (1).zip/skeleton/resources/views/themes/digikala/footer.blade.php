<footer style="padding:20px;background:#fafafa;border-top:1px solid #eee;margin-top:30px;text-align:center;">
  © {{ date('Y') }} Digikala Skeleton. All rights reserved.
</footer>
