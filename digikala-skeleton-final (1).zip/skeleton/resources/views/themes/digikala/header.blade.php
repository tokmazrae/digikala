<header class="header">
    <div class="container" style="display:flex;align-items:center;justify-content:space-between;">
        <div><a href="/"> <strong>دیجی‌کالا - اسکلت</strong></a></div>
        <div style="flex:1;margin:0 20px;">
            <input placeholder="جستجو در دیجی‌کالا..." style="width:100%;padding:8px;border-radius:6px;border:1px solid #ddd;" />
        </div>
        <div><a href="/admin">پنل مدیریت</a></div>
    </div>
</header>
