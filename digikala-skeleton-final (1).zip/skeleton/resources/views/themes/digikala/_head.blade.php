<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ config('app.name', 'Digikala Skeleton') }}</title>
<link rel="stylesheet" href="/themes/digikala/css/style.css">
<style>
/* basic RTL layout */
body { font-family: Vazir, sans-serif; direction: rtl; }
.header { background:#f5f5f7; padding:12px 20px; border-bottom:1px solid #eee; }
</style>
