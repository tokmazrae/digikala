<!doctype html>
<html lang="fa">
<head>
    @include("themes.$activeTheme._head")
</head>
<body>
    @include("themes.$activeTheme.header")
    <main>
        @yield('content')
    </main>
    @include("themes.$activeTheme.footer")
    <script src="/js/app.js"></script>
</body>
</html>
