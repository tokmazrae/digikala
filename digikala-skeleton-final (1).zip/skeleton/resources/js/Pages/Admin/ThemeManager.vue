<template>
  <div style="padding:20px;">
    <h2>مدیریت قالب</h2>
    <div v-for="t in available" :key="t" style="margin:12px 0;padding:12px;border:1px solid #eee;border-radius:8px;">
      <strong>{{ t }}</strong>
      <div style="margin-top:8px;">
        <button @click="activate(t)">فعال کن</button>
        <span v-if="active===t" style="margin-right:12px;color:green;">(فعال)</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    available: Array,
    active: String
  },
  methods: {
    activate(theme){
      this.$inertia.post('/admin/theme', { theme });
    }
  }
}
</script>
