<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model {
    protected $fillable = ['key','value'];

    public static function get($key, $default = null) {
        $s = static::where('key', $key)->first();
        if (! $s) return $default;
        $v = $s->value;
        // try json decode
        $decoded = @json_decode($v, true);
        return $decoded === null && json_last_error() !== JSON_ERROR_NONE ? $v : $decoded;
    }

    public static function set($key, $value) {
        return static::updateOrCreate(
            ['key' => $key],
            ['value' => is_array($value) || is_object($value) ? json_encode($value) : $value]
        );
    }
}
