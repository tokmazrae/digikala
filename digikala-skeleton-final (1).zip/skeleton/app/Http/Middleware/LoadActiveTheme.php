<?php
namespace App\Http\Middleware;

use Closure;
use App\Models\Setting;

class LoadActiveTheme {
    public function handle($request, Closure $next) {
        $theme = Setting::get('site_theme', 'digikala');
        view()->share('activeTheme', $theme);
        return $next($request);
    }
}
