<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Admin\ThemeController;

Route::get('/', [HomeController::class, 'index']);

Route::group(['prefix'=>'admin','middleware'=>['auth','role:admin']], function(){
    Route::get('theme', [ThemeController::class,'index']);
    Route::post('theme', [ThemeController::class,'update']);
});

// payment stubs
Route::post('/pay/create', [\App\Http\Controllers\PaymentController::class,'create']);
Route::get('/pay/callback', [\App\Http\Controllers\PaymentController::class,'callback']);
